package cl.inacap.cloudled

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import cl.inacap.cloudled.ui.MonitorViewModel
import cl.inacap.cloudled.ui.PantallaMonitor
import cl.inacap.cloudled.ui.theme.CloudLedTheme


class MainActivity : ComponentActivity() {
    @SuppressLint("ViewModelConstructorInComposable")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CloudLedTheme {
                val vistaModelo = MonitorViewModel()
                PantallaMonitor(vm = vistaModelo)
            }
        }
    }
}

